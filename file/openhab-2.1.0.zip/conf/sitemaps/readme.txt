Your sitemap definitions go here.
All sitemap files have to have the ".sitemap" file extension and must follow a special syntax.

Check out the openHAB documentation for more details:
http://docs.openhab.org/features/sitemap.html
